CREATE TABLE Entity1
(
	Id INTEGER AUTOINCREMENT PRIMARY KEY NOT NULL, /* This is a block comment -- not a line comment */ Column1 INTEGER 
)
