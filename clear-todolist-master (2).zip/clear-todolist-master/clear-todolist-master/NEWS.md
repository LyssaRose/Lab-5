bug fixes
