ALTER TABLE tbThing ADD content TEXT;
