package douzifly.list.utils

import android.content.Context

/**
 * Created by douzifly on 1/13/16.
 */

fun Int.toResString(context: Context):String = context.resources.getString(this)