#List [![Build Status](https://travis-ci.org/douzifly/clear-todolist.svg?branch=master)](https://travis-ci.org/douzifly/clear-todolist)

Clear List helps people quickly capture what’s on their mind and get a reminder later at the right time.
Provide two Clear and beautiful material designed theme to make use experience better. 
We don't upload your data to any server, even never connect to internet, keep your private data more security.

see:https://play.google.com/store/apps/details?id=douzifly.list
